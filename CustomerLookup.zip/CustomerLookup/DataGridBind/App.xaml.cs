﻿using System.Windows;

namespace DataGridBind
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        MainWindow main = new MainWindow();
        
    }
}
