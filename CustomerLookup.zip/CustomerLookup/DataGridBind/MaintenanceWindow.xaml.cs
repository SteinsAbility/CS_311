﻿using System;
using System.Windows;
using System.Data;
using MySql.Data.MySqlClient;
using System.Configuration;


namespace DataGridBind
{
    /// <summary>
    /// Interaction logic for MaintenanceWindow.xaml
    /// </summary>
    public partial class MaintenanceWindow : Window
    {
        MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        public MaintenanceWindow()
        {
            InitializeComponent();
        }

        private void deleteButton_Click(object sender, RoutedEventArgs e)
        {
            if(customerid.Text != string.Empty)
            {
                try
                {
                    if (MessageBox.Show("Do you wish to Delete this Customer?", "Confirm", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                    {
                        conn.Open();

                        String query = ("Delete from customers where CustomerID = '" + customerid.Text + "';");

                        MySqlCommand cmd = new MySqlCommand(query, conn);

                        MySqlDataReader myReader2;

                        myReader2 = cmd.ExecuteReader();

                        ((MainWindow)this.Owner).loadData();

                        conn.Close();

                       
                        deleteButton.IsEnabled = false;
                        editButton.IsEnabled = false;
                        addButton.IsEnabled = true;
                    }
                    else
                    {
                    
                    }
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show(ex.ToString());
                }
                finally
                {
                    conn.Close();
                }



            }
            else
            {
                MessageBox.Show("Please enter a Customer ID");
            }
        }

        private void editButton_Click(object sender, RoutedEventArgs e)
        {
            if (customerid.Text != string.Empty && nametxt.Text != string.Empty && addresstxt.Text != string.Empty && citytxt.Text != string.Empty && ziptxt.Text != string.Empty)
            {
                try
                {
                    if (MessageBox.Show("Do you wish to Update this Customer?", "Confirm", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                    {
                        conn.Open();

                        String query = "update customers set ContactName ='" + nametxt.Text + "', Address ='" + addresstxt.Text + "', PostalCode ='" + ziptxt.Text + "', Phone = '" + phonetxt.Text + "', City ='" + citytxt.Text + "' where CustomerID = '" + customerid.Text + "';";

                        MySqlCommand cmd = new MySqlCommand(query, conn);

                        MySqlDataReader myReader2;

                        myReader2 = cmd.ExecuteReader();

                        ((MainWindow)this.Owner).loadData();

                        conn.Close();
                    }
                    else
                    {

                    }
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show(ex.ToString());
                }
                finally
                {
                    conn.Close();
                }
            }
            else
            {
                MessageBox.Show("Please enter all fields or press Get Customer to update a new customer");
            }
        }

        private void closeButton_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Exit the Customer Maintenance Window?", "Confirm", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                this.Hide();
            }
            else
            {

            }
        }

        private void addButton_Click(object sender, RoutedEventArgs e)
        {
            if (customerid.Text != string.Empty && nametxt.Text != string.Empty && addresstxt.Text != string.Empty && citytxt.Text != string.Empty && ziptxt.Text != string.Empty)
            {
                try
                {
                    if (MessageBox.Show("Do you wish to Add this Customer?", "Confirm", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                    {
                        if (customerid.Text.Length >= 6)
                        {
                            MessageBox.Show("Customer ID is too long. Please edit and try again,.");
                        }
                        else if (ziptxt.Text.Length >= 11)
                        {
                            MessageBox.Show("Zip code is too long. Please edit and try again,.");
                        }
                        else
                        {
                            conn.Open();
                            try
                            {
                                String query = "insert into customers (CustomerId, ContactName, Address, City, PostalCode, Phone, CompanyName, Email) VALUES ('" + customerid.Text + "', '" + nametxt.Text + "', '" + addresstxt.Text + "', '" +
                                    citytxt.Text + "', '" + ziptxt.Text + "', '" + phonetxt.Text + "', 'None', 'none@email.com');";

                                MySqlCommand cmd = new MySqlCommand(query, conn);

                                MySqlDataReader myReader2;

                                myReader2 = cmd.ExecuteReader();

                                ((MainWindow)this.Owner).loadData();

                                addButton.IsEnabled = false;
                                deleteButton.IsEnabled = true;
                                editButton.IsEnabled = true;
                                conn.Close();
                            }

                            catch(MySqlException)
                            {
                                MessageBox.Show("User cannot be added. Please make sure you are using a unique ID.");
                            }
                        }
                    }
                    else
                    {

                    }
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show(ex.ToString());
                }
                finally
                {
                    conn.Close();
                }
            }
            else
            {
                MessageBox.Show("Please enter all fields to add a new customer");
            }
        }

        private void Button_Click_Get(object sender, RoutedEventArgs e)
        {
            if (customerid.Text != string.Empty)
            {
                try
                {

                    conn.Open();
                    String query = "Select ContactName, Address, City, Phone, PostalCode from customers where customerID = '" + customerid.Text + "'";
                    DataTable tbl = new DataTable();
                    MySqlDataReader myReader = null;
                    MySqlCommand myCommand = new MySqlCommand(query, conn);
                    myReader = myCommand.ExecuteReader();
                    while (myReader.Read())
                    {
                        nametxt.Text = (myReader["ContactName"].ToString());
                        addresstxt.Text = (myReader["Address"].ToString());
                        citytxt.Text = (myReader["City"].ToString());
                        phonetxt.Text = (myReader["Phone"].ToString());
                        ziptxt.Text = (myReader["PostalCode"].ToString());
                    }
                    if(nametxt.Text == string.Empty && addresstxt.Text == string.Empty && citytxt.Text == string.Empty && phonetxt.Text == string.Empty && ziptxt.Text == string.Empty)
                    {
                        MessageBox.Show("User not found, please try again.");
                    }
                    else
                    {
                        addButton.IsEnabled = false;
                        editButton.IsEnabled = true;
                        deleteButton.IsEnabled = true;
                    }
                    
                    conn.Close();
                 }
                catch (MySqlException ex)
                {
                    MessageBox.Show(ex.ToString());
                }
                finally
                {
                    conn.Close();
                }
            }
            else
            {
                MessageBox.Show("Please enter a Customer ID");
            }
            
        }

        private void clearBtn_Click(object sender, RoutedEventArgs e)
        {
            customerid.Clear();
            nametxt.Clear();
            addresstxt.Clear();
            citytxt.Clear();
            ziptxt.Clear();
            phonetxt.Clear();
            deleteButton.IsEnabled = false;
            editButton.IsEnabled = false;
            addButton.IsEnabled = true;
        }
    }
}
