﻿using System;
using System.Windows;
using System.Data;
using MySql.Data.MySqlClient;
using System.Configuration;


namespace DataGridBind
{
    /// <summary>
    /// Interaction logic for MaintenanceWindow.xaml
    /// </summary>
    public partial class MaintenanceWindow : Window
    {
        MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        public MaintenanceWindow()
        {
            InitializeComponent();
        }

        private void deleteButton_Click(object sender, RoutedEventArgs e)
        {
            if(champid.Text != string.Empty)
            {
                try
                {
                    if (MessageBox.Show("Do you wish to Delete this Champion?", "Confirm", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                    {
                        conn.Open();

                        String query = ("Delete from test6 where ChampID = '" + champid.Text + "';");

                        MySqlCommand cmd = new MySqlCommand(query, conn);

                        MySqlDataReader myReader2;

                        myReader2 = cmd.ExecuteReader();

                        ((MainWindow)this.Owner).loadData();

                        conn.Close();
                    }
                    else
                    {
                    
                    }
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show(ex.ToString());
                }
                finally
                {
                    conn.Close();
                }



            }
            else
            {
                MessageBox.Show("Please enter a Champion ID");
            }
        }

        private void updatebtn_Click(object sender, RoutedEventArgs e)
        {
            if (champid.Text != string.Empty && nametxt.Text != string.Empty && primarytxt.Text != string.Empty && secondarytxt.Text != string.Empty && difftxt.Text != string.Empty)
            {
                try
                {
                    if (MessageBox.Show("Do you wish to Update this Champion?", "Confirm", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                    {
                        conn.Open();

                        String query = "update customer.test6 set Name ='" + nametxt.Text + "', PrimaryAtt ='" + primarytxt.Text + "', Difficulty ='" + difftxt.Text + "', Price = '" + pricetxt.Text + "', SecondaryAtt ='" + secondarytxt.Text + "' where ChampID = '" + champid.Text + "';";

                        MySqlCommand cmd = new MySqlCommand(query, conn);

                        MySqlDataReader myReader2;

                        myReader2 = cmd.ExecuteReader();

                        ((MainWindow)this.Owner).loadData();

                        conn.Close();
                    }
                    else
                    {

                    }
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show(ex.ToString());
                }
                finally
                {
                    conn.Close();
                }
            }
            else
            {
                MessageBox.Show("Please enter all fields or press Get Champion to update a new champion");
            }
        }

        private void exitbtn_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Exit the Champion Maintenance Window?", "Confirm", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                this.Close();
            }
            else
            {

            }
        }

        private void insertbtn_Click(object sender, RoutedEventArgs e)
        {
            if (champid.Text != string.Empty && nametxt.Text != string.Empty && primarytxt.Text != string.Empty && secondarytxt.Text != string.Empty && difftxt.Text != string.Empty)
            {
                try
                {
                    if (MessageBox.Show("Do you wish to Insert this Champion?", "Confirm", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                    {
                        conn.Open();

                        String query = "insert into test6 (ChampID, Name, PrimaryAtt, SecondaryAtt, Difficulty, Price) VALUES ('" + champid.Text + "', '" + nametxt.Text + "', '" + primarytxt.Text + "', '" +
                            secondarytxt.Text + "', '" + difftxt.Text + "', '" + pricetxt.Text + "');";

                        MySqlCommand cmd = new MySqlCommand(query, conn);

                        MySqlDataReader myReader2;

                        myReader2 = cmd.ExecuteReader();

                        ((MainWindow)this.Owner).loadData();

                        conn.Close();
                    }
                    else
                    {

                    }
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show(ex.ToString());
                }
                finally
                {
                    conn.Close();
                }
            }
            else
            {
                MessageBox.Show("Please enter all fields to insert a new champion");
            }
        }

        private void Button_Click_Get(object sender, RoutedEventArgs e)
        {
            if (champid.Text != string.Empty)
            {
                try
                {

                    conn.Open();
                    String query = "Select Name, PrimaryAtt, SecondaryAtt, Price, Difficulty from test6 where ChampID = '" + champid.Text + "'";
                    DataTable tbl = new DataTable();
                    MySqlDataReader myReader = null;
                    MySqlCommand myCommand = new MySqlCommand(query, conn);
                    myReader = myCommand.ExecuteReader();
                    while (myReader.Read())
                    {
                        nametxt.Text = (myReader["Name"].ToString());
                        primarytxt.Text = (myReader["PrimaryAtt"].ToString());
                        secondarytxt.Text = (myReader["SecondaryAtt"].ToString());
                        pricetxt.Text = (myReader["Price"].ToString());
                        difftxt.Text = (myReader["Difficulty"].ToString());
                    }
                    conn.Close();
                 }
                catch (MySqlException ex)
                {
                    MessageBox.Show(ex.ToString());
                }
                finally
                {
                    conn.Close();
                }
            }
            else
            {
                MessageBox.Show("Please enter a Champion ID");
            }
            
        }
    }
}
